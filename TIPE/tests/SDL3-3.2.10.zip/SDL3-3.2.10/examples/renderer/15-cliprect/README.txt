This example creates an SDL window and renderer, loads a texture
from a .bmp file, and stretches it across the window. Each frame, we move
the clipping rectangle around, so only a small square of the texture is
actually drawn.

