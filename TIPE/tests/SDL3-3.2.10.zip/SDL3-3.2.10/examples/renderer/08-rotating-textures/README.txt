This example creates an SDL window and renderer, loads a texture from a .bmp
file, and then draws it, rotating around the center of the screen.

