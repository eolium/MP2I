If you're running this in a web browser, you need to click the window before you'll hear anything!

This example code creates a simple audio stream for playing sound, and
generates a sine wave sound effect for it to play as time goes on. This is the
simplest way to get up and running with procedural sound.
